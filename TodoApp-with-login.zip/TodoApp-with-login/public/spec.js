describe('Login Page', function() {
    it('should greet the named user', function() {
      browser.get('https://todo-list-login.firebaseapp.com/');
      element(by.id('login.loginWithGithub()')).click();

      expect(browser.getTitle()).toEqual('Todo Lists');
    });
  });
 
  describe('Input App', function() {
    var homeList = element(by.model('home.list'));
    var goButton = element(by.id('home.list && home.add()'));
    var latestResult = element(by.binding('home.lists'));
  
    beforeEach(function() {
      browser.get('https://todo-list-login.firebaseapp.com/#!/home');
    });
  
    it('should add 1', function() {
        homeList.sendKeys(1);
        goButton.click();
      expect(latestResult.getText()).toEqual('1');
    });
    it('should add 2', function() {
        homeList.sendKeys(2);
        goButton.click();
      expect(latestResult.getText()).toEqual('2');
    });
    it('should add 3', function() {
        homeList.sendKeys(3);
        goButton.click();
      expect(latestResult.getText()).toEqual('3');
    });
    it('should add 4', function() {
        homeList.sendKeys(4);
        goButton.click();
      expect(latestResult.getText()).toEqual('4');
    });
    it('should add 5', function() {
        homeList.sendKeys(5);
        goButton.click();
      expect(latestResult.getText()).toEqual('5');
    });
    it('should add 6', function() {
        homeList.sendKeys(6);
        goButton.click();
      expect(latestResult.getText()).toEqual('6');
    });
    it('should add 7', function() {
        homeList.sendKeys(7);
        goButton.click();
      expect(latestResult.getText()).toEqual('7');
    });
    it('should add 8', function() {
        homeList.sendKeys(8);
        goButton.click();
      expect(latestResult.getText()).toEqual('8');
    });
    it('should add 9', function() {
        homeList.sendKeys(9);
        goButton.click();
      expect(latestResult.getText()).toEqual('9');
    });
    it('should add 10', function() {
        homeList.sendKeys(10);
        goButton.click();
      expect(latestResult.getText()).toEqual('10');
    });
  
  });

  describe('Logout Page', function() {
    it('Logout', function() {
      var latestResult = element(by.binding('home.lists'));

      browser.get('https://todo-list-login.firebaseapp.com/#!/');
      element(by.id('home.signOut()')).click();
      browser.get('https://todo-list-login.firebaseapp.com/');
      expect(latestResult.getText()).toEqual('1');
      expect(latestResult.getText()).toEqual('2');
      expect(latestResult.getText()).toEqual('3');
      expect(latestResult.getText()).toEqual('4');
      expect(latestResult.getText()).toEqual('5');
      expect(latestResult.getText()).toEqual('6');
      expect(latestResult.getText()).toEqual('7');
      expect(latestResult.getText()).toEqual('8');
      expect(latestResult.getText()).toEqual('9');
      expect(latestResult.getText()).toEqual('10');
    });
  });

  describe('Delete App', function() {
    var goButton = element(by.id('home.delete($index)'));
    var latestResult = element(by.binding('home.lists'));
  
    beforeEach(function() {
      browser.get('https://todo-list-login.firebaseapp.com/#!/home');
    });
  
    it('should add 10', function() {
        goButton.click();
      expect(latestResult.getText()).toEqual('9');
    });
    it('should add 9', function() {
        goButton.click();
      expect(latestResult.getText()).toEqual('8');
    });
    it('should add 8', function() {
        goButton.click();
      expect(latestResult.getText()).toEqual('7');
    });
    it('should add 7', function() {
        goButton.click();
      expect(latestResult.getText()).toEqual('6');
    });
    it('should add 6', function() {
        goButton.click();
      expect(latestResult.getText()).toEqual('5');
    });
    it('should add 5', function() {
        goButton.click();
      expect(latestResult.getText()).toEqual('4');
    });
  });

  describe('Logout Page', function() {
    it('Logout', function() {
      var latestResult = element(by.binding('home.lists'));

      browser.get('https://todo-list-login.firebaseapp.com/#!/');
      element(by.id('home.signOut()')).click();
      browser.get('https://todo-list-login.firebaseapp.com/');

      expect(latestResult.getText()).toEqual('1');
      expect(latestResult.getText()).toEqual('2');
      expect(latestResult.getText()).toEqual('3');
      expect(latestResult.getText()).toEqual('4');

    });
  );